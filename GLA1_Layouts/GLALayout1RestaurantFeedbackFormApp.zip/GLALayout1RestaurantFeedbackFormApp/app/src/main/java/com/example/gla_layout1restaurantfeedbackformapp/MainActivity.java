package com.example.gla_layout1restaurantfeedbackformapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {

    private TextInputLayout name;
    private TextInputLayout email;
    private TextInputLayout msg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.ip_name);
        email = findViewById(R.id.ip_email);
        msg = findViewById(R.id.ip_msg);
    }

    public void displayMessege(View view) {

        String nameTyped = name.getEditText().getText().toString();
        String emailTyped = email.getEditText().getText().toString();
        String msgTyped = msg.getEditText().getText().toString();
        boolean isNameEmpty = !nameTyped.isEmpty();
        boolean isEmailEmpty = !emailTyped.isEmpty();
        boolean isMsgInput = !msgTyped.isEmpty();

        if (isNameEmpty && isEmailEmpty && isMsgInput){

            System.out.println("Name: " +nameTyped + " | Email: " + emailTyped + " | Messege: " + msgTyped);

            String output = "Name: " + nameTyped + "\n";
            output += "Email: " +  emailTyped + "\n";
            output += "Your messege is:\n" +  msgTyped;

                Toast.makeText(this,output,Toast.LENGTH_LONG).show();

                    name.getEditText().setText("");
                    email.getEditText().setText("");
                    msg.getEditText().setText("");
        }
        else{
            Toast.makeText(this,"ERROR! Try Again",Toast.LENGTH_SHORT).show();
            System.out.println("Name: " +nameTyped + " | Email: " + emailTyped + " | Messege: " + msgTyped);
        }
    }
}