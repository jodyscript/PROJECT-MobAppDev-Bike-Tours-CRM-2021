package com.jody.tictactoe_assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import static com.jody.tictactoe_assignment.R.color.crosses_custom;
import static com.jody.tictactoe_assignment.R.color.noughts_custom;
import static com.jody.tictactoe_assignment.R.color.white;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Setup global variables to assign to views
    private TextView X_Score, O_Score, update_Text;
    private Button reset_BTN;
    private Button[] buttons = new Button[9];

    private int X_ScoreCount, O_ScoreCount; // Holds game won by each
    private int roundCount; // Records turns taken, max of 9.
    boolean activeTurnO; // Bool to indicate who's turn it is.

    // Using an array to store button state, 2 is empty, 0 is Nought, 1 is Cross
    int[] gameState = {2, 2, 2, 2, 2, 2, 2, 2, 2};
    // Multi Dimension array to record all winning combos, H, V, Dia.
    int[][] winningPositions = {
            {0, 1, 2}, {3, 4, 5}, {6, 7, 8},
            {0, 3, 6}, {1, 4, 7}, {2, 5, 8},
            {0, 4, 8}, {2, 4, 6}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Selecting views from xml
        X_Score = (TextView) findViewById(R.id.playerXScore);
        O_Score = (TextView) findViewById(R.id.playerOScore);
        update_Text = (TextView) findViewById(R.id.update_Msg);
        reset_BTN = (Button) findViewById(R.id.btn_reset);
        // Loop to get each button by id, set OnClick even to btn
        for (int i = 0; i < buttons.length; i++) {
            String buttonID = "btn_" + i;
            int resourceID = getResources().getIdentifier(buttonID, "id", getPackageName());
            buttons[i] = (Button) findViewById(resourceID);
            buttons[i].setOnClickListener(this);
        }
        // Initial counts for score and turns
        roundCount = 0;
        X_ScoreCount = 0;
        O_ScoreCount = 0;
        activeTurnO = true;

    }

    @Override
    public void onClick(View v) {
        // Do nothing if the button text is occupied
        if (!((Button) v).getText().toString().equals("")) return;
        // Grab button id and substring to get exact value
        String buttonID = v.getResources().getResourceEntryName(v.getId());
        int gameStatePointer = Integer.parseInt(buttonID.substring(buttonID.length() - 1, buttonID.length()));

        // Depending on who's turn it is set the btn text value to correct player.
        if (activeTurnO) {
            ((Button) v).setText("O");
            ((Button) v).setTextColor(Color.parseColor("#ff8a65"));
            gameState[gameStatePointer] = 0;
        } else {
            ((Button) v).setText("X");
            ((Button) v).setTextColor(Color.parseColor("#ffee58"));
            gameState[gameStatePointer] = 1;
        }
        roundCount++; // Each turn increase count to verify if draw after 9 turns.

        if(checkForWinner()){ // If true update scoreboard based on active player
            if (activeTurnO){
                O_ScoreCount++;
                updateScores();
                Toast.makeText(this, "Noughts Won!", Toast.LENGTH_LONG).show();
            } else {
                X_ScoreCount++;
                updateScores();
                Toast.makeText(this, "Crosses Won!", Toast.LENGTH_LONG).show();
            }
            newGame();
        } else if(roundCount == 9){ // Draw condition
            newGame();
            Toast.makeText(this, "Close Match, DRAW!", Toast.LENGTH_LONG).show();
        } else {
            activeTurnO = !activeTurnO;
            // Change player if above conditions not met. Continue game.
        }

        // Update msg to show who's turn it is.
        if(activeTurnO){
            update_Text.setTextColor(getColor(noughts_custom));
            update_Text.setText(R.string.noughts_turn);
        } else {
            update_Text.setTextColor(getColor(crosses_custom));
            update_Text.setText(R.string.crosses_turn);
        }

        // OnClick game scores and board are reset
        reset_BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newGame();
                X_ScoreCount = 0;
                O_ScoreCount = 0;
                update_Text.setTextColor(getColor(white));
                update_Text.setText(R.string.turn_message);
                updateScores();
            }
        });
    }

    public boolean checkForWinner() {
        // No winner to start
        boolean winnerResult = false;
        // Checking if winning positions
        for (int[] winnerCheck : winningPositions){
            if (gameState[winnerCheck[0]] == gameState[winnerCheck[1]] &&
                    gameState[winnerCheck[1]] == gameState[winnerCheck[2]] &&
                    gameState[winnerCheck[0]] != 2) {
                winnerResult = true;
                break;
                // The last condition is checking that 2 is not matching as this is the start condition.
            }
        }
        return winnerResult; // Returns false, no winner if condition above is not met.
    }

    // Updates main scoreboard
    public void updateScores(){
        X_Score.setText(String.valueOf(X_ScoreCount));
        O_Score.setText(String.valueOf(O_ScoreCount));
    }

    // Reset's all values and offers new game.
    public void newGame(){
        roundCount = 0;
        activeTurnO = true;

        for(int i = 0; i < buttons.length; i++){
            gameState[i] = 2;
            buttons[i].setText("");
        }
    }
}